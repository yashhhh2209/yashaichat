import os
import json
from typing import List, Dict, Any, Optional
import google.generativeai as genai
from langchain_google_genai import ChatGoogleGenerativeAI
from .models import ChatResponse, Action

class LLMService:
    def __init__(self):
        # Configure Gemini API
        self.api_key = "AIzaSyCDMHqvyv7L7X9bUpnYdPxYFTmZi-Y15QI"
        genai.configure(api_key=self.api_key)
        
        # Initialize Gemini model
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        self.chat_model = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=self.api_key,
            temperature=0.7,
            max_output_tokens=1000
        )
        
        # Emergency keywords that trigger safety flags
        self.emergency_keywords = [
            "chest pain", "heart attack", "stroke", "suicidal", "suicide",
            "bleeding", "unconscious", "seizure", "difficulty breathing",
            "severe pain", "trauma", "accident", "overdose"
        ]
        
        # PHI (Protected Health Information) keywords
        self.phi_keywords = [
            "my medical record", "my diagnosis", "my test results",
            "my prescription", "my treatment", "my history"
        ]
        
        print("✅ Gemini AI LLM Service initialized successfully!")
    
    def detect_emergency(self, query: str) -> bool:
        """Detect if query contains emergency keywords"""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.emergency_keywords)
    
    def detect_phi_request(self, query: str) -> bool:
        """Detect if query is requesting PHI"""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.phi_keywords)
    
    def detect_medical_advice(self, query: str) -> bool:
        """Detect if query is asking for medical advice"""
        medical_advice_keywords = [
            "should i", "what should i do", "is it serious", "do i need",
            "treatment for", "medicine for", "dosage", "diagnosis"
        ]
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in medical_advice_keywords)
    
    def generate_response(self, query: str, retrieved_docs: List[Dict[str, Any]], 
                         patient_id: Optional[str] = None) -> ChatResponse:
        """Generate response using Gemini AI with RAG context"""
        
        # Check for emergency situations
        if self.detect_emergency(query):
            return self._generate_emergency_response(query)
        
        # Check for PHI requests
        if self.detect_phi_request(query) and not patient_id:
            return self._generate_phi_denial_response(query)
        
        # Check for medical advice
        if self.detect_medical_advice(query):
            return self._generate_medical_disclaimer_response(query, retrieved_docs)
        
        # Generate normal response with RAG
        return self._generate_rag_response(query, retrieved_docs)
    
    def _generate_emergency_response(self, query: str) -> ChatResponse:
        """Generate emergency response"""
        return ChatResponse(
            answer="🚨 EMERGENCY ALERT: This appears to be a medical emergency. Please call 911 or visit the nearest emergency room immediately. Do not wait for a response from this chatbot. Your safety is our priority.",
            citations=["emergency_protocols"],
            follow_up_questions=[
                "Have you called emergency services?",
                "Are you currently at a hospital?",
                "Do you need help finding the nearest emergency room?"
            ],
            confidence="high",
            safety_flags=["EMERGENCY"],
            actions=[Action(type="NONE")]
        )
    
    def _generate_phi_denial_response(self, query: str) -> ChatResponse:
        """Generate response denying PHI access"""
        return ChatResponse(
            answer="I cannot access your personal medical information without proper authentication. Please contact our support team or log into your patient portal to access your medical records.",
            citations=[],
            follow_up_questions=[
                "Would you like help logging into your patient portal?",
                "Would you like to speak with a patient representative?",
                "Do you need help with appointment scheduling?"
            ],
            confidence="high",
            safety_flags=["PHI_REQUEST"],
            actions=[Action(type="TOOL_CALL", tool="ticket_create", args={"issue": "PHI access request"})]
        )
    
    def _generate_medical_disclaimer_response(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> ChatResponse:
        """Generate response with medical disclaimer using Gemini"""
        try:
            context = self._format_context(retrieved_docs)
            
            prompt = f"""
            You are a helpful healthcare assistant. A user asked: "{query}"
            
            Context from hospital documents: {context}
            
            Please provide a helpful response based on the hospital information provided. 
            Always end with: "⚠️ This is general information, not a medical diagnosis. Please consult with a healthcare provider for personalized medical advice."
            
            Keep the response conversational and helpful.
            """
            
            response = self.model.generate_content(prompt)
            answer = response.text.strip()
            
            if not answer:
                answer = self._generate_fallback_medical_response(query, retrieved_docs).answer
                
        except Exception as e:
            print(f"Gemini generation failed: {e}")
            answer = self._generate_fallback_medical_response(query, retrieved_docs).answer
        
        # Extract citations
        citations = [doc["metadata"]["title"] for doc in retrieved_docs if doc["score"] < 0.8]
        
        # Determine confidence based on document relevance
        avg_score = sum(doc["score"] for doc in retrieved_docs) / len(retrieved_docs) if retrieved_docs else 1.0
        if avg_score < 0.5:
            confidence = "high"
        elif avg_score < 0.8:
            confidence = "medium"
        else:
            confidence = "low"
        
        return ChatResponse(
            answer=answer,
            citations=citations,
            follow_up_questions=[
                "Would you like to schedule an appointment with a specialist?",
                "Do you have any other questions about this topic?",
                "Would you like me to connect you with a patient representative?"
            ],
            confidence=confidence,
            safety_flags=["MED_ADVICE"],
            actions=[Action(type="NONE")]
        )
    
    def _generate_rag_response(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> ChatResponse:
        """Generate response using RAG context with Gemini"""
        if not retrieved_docs:
            # If no relevant docs found, generate a general response
            return self._generate_general_response(query)
        
        context = self._format_context(retrieved_docs)
        
        try:
            prompt = f"""
            You are a helpful healthcare assistant. A user asked: "{query}"
            
            Context from hospital documents: {context}
            
            Please provide a helpful and accurate response based on the hospital information provided.
            Be conversational and engaging. If the information isn't in the context, say so politely.
            
            Keep the response helpful and informative.
            """
            
            response = self.model.generate_content(prompt)
            answer = response.text.strip()
            
            if not answer:
                answer = self._generate_fallback_rag_response(query, retrieved_docs).answer
                
        except Exception as e:
            print(f"Gemini generation failed: {e}")
            answer = self._generate_fallback_rag_response(query, retrieved_docs).answer
        
        # Extract citations
        citations = [doc["metadata"]["title"] for doc in retrieved_docs if doc["score"] < 0.8]
        
        # Determine confidence based on document relevance
        avg_score = sum(doc["score"] for doc in retrieved_docs) / len(retrieved_docs) if retrieved_docs else 1.0
        if avg_score < 0.5:
            confidence = "high"
        elif avg_score < 0.8:
            confidence = "medium"
        else:
            confidence = "low"
        
        return ChatResponse(
            answer=answer,
            citations=citations,
            follow_up_questions=[
                "Is there anything else you'd like to know about this topic?",
                "Would you like help with scheduling or other services?",
                "Do you have any other questions?"
            ],
            confidence=confidence,
            safety_flags=["NONE"],
            actions=[Action(type="NONE")]
        )

    def _generate_general_response(self, query: str) -> ChatResponse:
        """Generate response for general questions when no docs are found"""
        try:
            prompt = f"""
            You are a helpful and friendly AI assistant. A user asked: "{query}"
            
            Please provide a conversational, engaging, and helpful response. 
            Be friendly and show interest in the topic. Ask follow-up questions to keep the conversation going.
            
            Keep the response conversational and engaging.
            """
            
            response = self.model.generate_content(prompt)
            answer = response.text.strip()
            
            if not answer:
                answer = f"That's a great question! {query} is an interesting topic. I'd love to help you explore this further. What specific aspect would you like to know more about?"
                
        except Exception as e:
            print(f"General response generation failed: {e}")
            answer = f"That's a great question! {query} is an interesting topic. I'd love to help you explore this further. What specific aspect would you like to know more about?"
        
        return ChatResponse(
            answer=answer,
            citations=[],
            follow_up_questions=[
                "What would you like to know more about?",
                "Can I help you with something else?",
                "Is there a specific aspect you'd like to explore?",
                "Would you like to chat about something else?"
            ],
            confidence="high",
            safety_flags=["NONE"],
            actions=[Action(type="NONE")]
        )
    
    def _generate_no_info_response(self) -> ChatResponse:
        """Generate response when no relevant information is found"""
        return ChatResponse(
            answer="I don't have specific information about that. Please contact our support team at 1800-HOSPITAL or visit the information desk for assistance.",
            citations=[],
            follow_up_questions=[
                "Would you like to speak with a patient representative?",
                "Can I help you with something else?",
                "Would you like to schedule an appointment?"
            ],
            confidence="low",
            safety_flags=["NONE"],
            actions=[Action(type="TOOL_CALL", tool="ticket_create", args={"issue": "Information request not found"})]
        )
    
    def _generate_fallback_medical_response(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> ChatResponse:
        """Generate fallback response for medical questions"""
        if retrieved_docs:
            best_doc = min(retrieved_docs, key=lambda x: x["score"])
            answer = f"Based on our hospital information: {best_doc['content'][:200]}...\n\n⚠️ This is general information, not a medical diagnosis. Please consult with a healthcare provider for personalized medical advice."
            citations = [best_doc["metadata"]["title"]]
            confidence = "medium"
        else:
            answer = "I can provide general healthcare information, but for medical advice, please consult with a healthcare provider. This is general information, not a medical diagnosis."
            citations = []
            confidence = "low"
        
        return ChatResponse(
            answer=answer,
            citations=citations,
            follow_up_questions=[
                "Would you like to schedule an appointment?",
                "Can I help you with other healthcare information?",
                "Would you like to speak with a patient representative?"
            ],
            confidence=confidence,
            safety_flags=["MED_ADVICE"],
            actions=[Action(type="NONE")]
        )
    
    def _generate_fallback_rag_response(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> ChatResponse:
        """Generate fallback response when LLM fails"""
        if retrieved_docs:
            best_doc = min(retrieved_docs, key=lambda x: x["score"])
            answer = f"Based on our hospital information: {best_doc['content'][:200]}...\n\nThis is general information, not a medical diagnosis. Please consult with a healthcare provider for personalized medical advice."
            citations = [best_doc["metadata"]["title"]]
            confidence = "medium"
        else:
            answer = "I'm having trouble processing your request right now. Please contact our support team at 1800-HOSPITAL for immediate assistance."
            citations = []
            confidence = "low"
        
        return ChatResponse(
            answer=answer,
            citations=citations,
            follow_up_questions=[
                "Would you like to speak with a human representative?",
                "Can I help you with something else?",
                "Would you like to try rephrasing your question?"
            ],
            confidence=confidence,
            safety_flags=["NONE"],
            actions=[Action(type="TOOL_CALL", tool="ticket_create", args={"issue": "LLM processing error"})]
        )
    
    def _format_context(self, retrieved_docs: List[Dict[str, Any]]) -> str:
        """Format retrieved documents for LLM context"""
        if not retrieved_docs:
            return "No relevant information found."
        
        context_parts = []
        for i, doc in enumerate(retrieved_docs, 1):
            context_parts.append(f"Document {i} ({doc['metadata']['title']}):\n{doc['content']}\n")
        
        return "\n".join(context_parts)
