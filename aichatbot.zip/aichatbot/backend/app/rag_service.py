import os
import json
from typing import List, Dict, Any
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

class RAGService:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        self.vector_store = None
        self.documents = []
        self.initialize_documents()
        self.create_vector_store()
    
    def initialize_documents(self):
        """Initialize sample hospital documents"""
        self.documents = [
            {
                "id": "opd_timings",
                "title": "OPD Timings",
                "content": """
                Outpatient Department (OPD) Timings:
                Monday to Friday: 8:00 AM - 6:00 PM
                Saturday: 8:00 AM - 2:00 PM
                Sunday: 9:00 AM - 1:00 PM (Emergency cases only)
                
                Special Clinics:
                Cardiology: Tuesday & Thursday, 2:00 PM - 5:00 PM
                Neurology: Monday & Wednesday, 2:00 PM - 5:00 PM
                Pediatrics: Monday to Friday, 9:00 AM - 4:00 PM
                """,
                "category": "appointments"
            },
            {
                "id": "insurance_policy",
                "title": "Insurance Policy Information",
                "content": """
                Cashless Insurance Claims:
                1. Pre-authorization required for planned procedures
                2. Network hospitals: 500+ hospitals across the country
                3. Coverage: Inpatient, outpatient, diagnostic tests
                4. Documents needed: Insurance card, ID proof, pre-authorization letter
                
                Claim Process:
                - Submit within 48 hours of admission
                - All bills must be submitted within 30 days
                - Cashless facility available at network hospitals
                - Reimbursement claims processed within 15 working days
                """,
                "category": "insurance"
            },
            {
                "id": "fever_guide",
                "title": "Fever Management Guide",
                "content": """
                Fever Management Guidelines:
                Normal body temperature: 98.6°F (37°C)
                Low-grade fever: 99°F - 100.4°F (37.2°C - 38°C)
                High fever: Above 100.4°F (38°C)
                
                Home Care:
                - Rest and hydration
                - Light clothing
                - Lukewarm sponge bath if above 103°F
                - Monitor for 3-5 days
                
                Seek Medical Attention:
                - Fever above 103°F for more than 3 days
                - Fever with severe headache, neck stiffness
                - Fever with rash or difficulty breathing
                """,
                "category": "health_guidance"
            },
            {
                "id": "appointment_booking",
                "title": "Appointment Booking Process",
                "content": """
                How to Book Appointments:
                1. Online: Visit hospital website or mobile app
                2. Phone: Call 1800-HOSPITAL (24/7)
                3. In-person: Visit appointment desk
                
                Required Information:
                - Patient name and age
                - Contact number
                - Preferred date and time
                - Department/doctor preference
                - Insurance details (if applicable)
                
                Cancellation Policy:
                - Free cancellation up to 24 hours before
                - Late cancellation may incur charges
                - No-show policy: 3 strikes in 6 months
                """,
                "category": "appointments"
            },
            {
                "id": "emergency_protocols",
                "title": "Emergency Protocols",
                "content": """
                Emergency Situations - Call 911 or visit ER immediately:
                
                Chest Pain:
                - Pressure, tightness, or pain in chest
                - Pain spreading to arms, neck, jaw
                - Accompanied by shortness of breath, sweating
                
                Stroke Symptoms (FAST):
                - Face drooping
                - Arm weakness
                - Speech difficulty
                - Time to call 911
                
                Severe Bleeding:
                - Apply direct pressure
                - Elevate if possible
                - Call emergency services
                
                Head Injury:
                - Loss of consciousness
                - Severe headache
                - Vomiting or confusion
                """,
                "category": "emergency"
            },
            {
                "id": "visiting_hours",
                "title": "Visiting Hours",
                "content": """
                General Ward Visiting Hours:
                Morning: 10:00 AM - 11:00 AM
                Evening: 5:00 PM - 7:00 PM
                
                ICU Visiting Hours:
                Morning: 10:00 AM - 10:30 AM
                Evening: 6:00 PM - 6:30 PM
                (Only immediate family, 2 visitors max)
                
                Pediatric Ward:
                Parents can stay 24/7
                Other visitors: 10:00 AM - 8:00 PM
                
                Maternity Ward:
                Father: 24/7 access
                Other visitors: 11:00 AM - 7:00 PM
                """,
                "category": "visiting"
            }
        ]
    
    def create_vector_store(self):
        """Create FAISS vector store from documents"""
        # Split documents into chunks
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=50
        )
        
        texts = []
        metadatas = []
        
        for doc in self.documents:
            chunks = text_splitter.split_text(doc["content"])
            for chunk in chunks:
                texts.append(chunk)
                metadatas.append({
                    "doc_id": doc["id"],
                    "title": doc["title"],
                    "category": doc["category"]
                })
        
        # Create vector store
        self.vector_store = FAISS.from_texts(
            texts=texts,
            embedding=self.embeddings,
            metadatas=metadatas
        )
    
    def search_documents(self, query: str, k: int = 3) -> List[Dict[str, Any]]:
        """Search for relevant documents using semantic similarity"""
        if not self.vector_store:
            return []
        
        # Check if query is hospital/healthcare related
        hospital_keywords = [
            "hospital", "doctor", "appointment", "emergency", "patient", "medical",
            "opd", "timing", "visiting", "hours", "department", "ward", "icu",
            "treatment", "medicine", "health", "care", "clinic", "nurse"
        ]
        
        query_lower = query.lower()
        is_hospital_related = any(keyword in query_lower for keyword in hospital_keywords)
        
        # If query is not hospital-related, return empty to allow general conversation
        if not is_hospital_related:
            return []
        
        # Search for similar documents only for hospital-related queries
        docs = self.vector_store.similarity_search_with_score(query, k=k)
        
        results = []
        for doc, score in docs:
            # Only include documents with good similarity scores
            if float(score) < 0.8:  # Lower score = better similarity
                results.append({
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "score": float(score)
                })
        
        return results
    
    def get_document_by_id(self, doc_id: str) -> Dict[str, Any]:
        """Get a specific document by ID"""
        for doc in self.documents:
            if doc["id"] == doc_id:
                return doc
        return None
