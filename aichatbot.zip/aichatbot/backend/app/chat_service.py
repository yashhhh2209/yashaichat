import asyncio
from typing import Optional, Dict, List, Any
from .rag_service import RAGService
from .llm_service import LLMService  # Changed back to LLMService
from .models import ChatRequest, ChatResponse
from .models import Action # Added missing import for Action

class HealthcareChatService:
    def __init__(self):
        self.rag_service = RAGService()
        self.llm_service = LLMService()  # Using Gemini LLM service
    
    def process_chat(self, request: ChatRequest) -> ChatResponse:
        """Process chat request using RAG and LLM"""
        try:
            # Retrieve relevant documents
            retrieved_docs = self.rag_service.search_documents(request.query)
            
            # Generate response using LLM
            response = self.llm_service.generate_response(
                query=request.query,
                retrieved_docs=retrieved_docs,
                patient_id=request.patient_id
            )
            
            return response
            
        except Exception as e:
            print(f"Error processing chat: {e}")
            return ChatResponse(
                answer="I'm sorry, I'm experiencing technical difficulties. Please try again or contact our support team.",
                citations=[],
                follow_up_questions=[
                    "Would you like to try asking your question again?",
                    "Would you like to speak with a human representative?",
                    "Can I help you with something else?"
                ],
                confidence="low",
                safety_flags=["TECHNICAL_ERROR"],
                actions=[Action(type="NONE")]
            )
    
    def _log_interaction(self, query: str, response: ChatResponse, 
                        patient_id: Optional[str], session_token: Optional[str]):
        """Log the interaction for monitoring and compliance"""
        # In production, this would log to a secure database
        log_entry = {
            "timestamp": asyncio.get_event_loop().time(),
            "query": query,
            "response_summary": {
                "confidence": response.confidence,
                "safety_flags": response.safety_flags,
                "has_citations": len(response.citations) > 0
            },
            "patient_id": patient_id,
            "session_verified": bool(session_token)
        }
        
        # For demo purposes, just print to console
        print(f"Interaction logged: {log_entry}")
    
    def get_emergency_contacts(self) -> Dict[str, str]:
        """Get emergency contact information"""
        return {
            "Emergency Services": "911",
            "Hospital Main": "1800-HOSPITAL",
            "Ambulance": "1800-AMBULANCE",
            "Poison Control": "1-800-222-1222"
        }
    
    def get_available_topics(self) -> List[Dict[str, Any]]:
        """Get available healthcare topics"""
        return [
            {
                "category": "General Information",
                "topics": ["OPD Timings", "Visiting Hours", "Contact Information"]
            },
            {
                "category": "Services",
                "topics": ["Appointment Booking", "Insurance", "Emergency Protocols"]
            },
            {
                "category": "Departments",
                "topics": ["Cardiology", "Orthopedics", "Pediatrics", "Maternity"]
            }
        ]
