from pydantic import BaseModel
from typing import List, Optional, Dict, Any, Literal

class Action(BaseModel):
    type: Literal["TOOL_CALL", "NONE"]
    tool: Optional[Literal["rag_search", "ehr_read", "appt_schedule", "ticket_create"]] = None
    args: Optional[Dict[str, Any]] = None

class ChatRequest(BaseModel):
    query: str
    patient_id: Optional[str] = None
    session_token: Optional[str] = None

class ChatResponse(BaseModel):
    answer: str
    citations: List[str]
    follow_up_questions: List[str]
    confidence: Literal["low", "medium", "high"]
    safety_flags: List[Literal["EMERGENCY", "PHI_REQUEST", "MED_ADVICE", "TECHNICAL_ERROR", "NONE"]]
    actions: List[Action]
