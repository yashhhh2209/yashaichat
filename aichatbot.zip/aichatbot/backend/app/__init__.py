# This file makes the backend/app directory a Python package
